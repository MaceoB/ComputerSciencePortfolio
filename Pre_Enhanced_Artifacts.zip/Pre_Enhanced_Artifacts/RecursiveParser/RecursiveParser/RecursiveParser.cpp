// RecursiveParser.cpp : This file contains the 'main' function. Program execution begins and ends there.
// Maceo Bramante
//ID: 2725073
//11/6/2023

#include <iostream>
#include <string>
#include <vector>
using namespace std;



//Prototype functions

bool digit();
bool nonzerodigit();
bool rest();
bool number();
bool alphanum();
bool alphanumrest();
bool alpha();
bool identifier();
bool factor();
bool term();
bool expr();
void getNextLexeme();
void undoAction();

//Define global variables

int lexeme_index = -1;
int num_lexemes;
string input;
char lexeme;


void getNextLexeme() {
	lexeme_index++;
	if (lexeme_index >= num_lexemes) {
		lexeme = '\0';
		return;
	}
	//Set lexeme
	lexeme = input.at(lexeme_index);
	//Skips empty lexeme or space
	while (lexeme == ' ' && lexeme_index < num_lexemes - 1) {
		lexeme_index++;
		lexeme = input.at(lexeme_index);
	}
}

bool digit() {
	return isdigit(lexeme); //Returns true of the lexeme is a digit
}

bool nonzerodigit() {
	return (isdigit(lexeme) && lexeme != '0'); // Returns true if the lexe is a digit that isn't zero
}

bool rest() {
	if (!digit()) return false;
	getNextLexeme();
	if (digit()) return rest(); //If the next lexeme is another digit then the function rest calls itself again
	return true; //Otherwise it returns true
}

bool number() {
	if (nonzerodigit()) {
		getNextLexeme();
		if (digit()) return rest();
		return true;
	}
	else if (digit()) {
		getNextLexeme();
		return true;
	}
	return false; //Returns false if the lexe isn't a real number
}

bool alpha() {
	if (lexeme == '_') return true;
	return (isalpha(lexeme)); //returns true if the lexeme is a letter or an underscore char
}

bool alphanum() {
	return (alpha() || digit()); //Returns digit or alpha if they are true
}

bool alphanumrest() {
	if (!alphanum()) return false; //Returns false if not digit or alpha
	getNextLexeme();
	if (alphanum()) return alphanumrest(); //If the next lexeme is another digit or alpha then the function calss itself again
	return true; //Otherwise it returns true
}

bool identifier() {
	if (!alpha()) return false; //checks if lexeme is a valid alpha
	getNextLexeme();
	if (alphanum()) return alphanumrest(); //calls alphanumrest if the lexe is a letter or number
	return true; //Otherwise returns true
}

bool factor() {
	if (isdigit(lexeme)) return number(); //Checks if lexeme is a number first
	else if (isalpha(lexeme) || lexeme == '_') return identifier(); //Next checks if its an a letter
	else if (lexeme == '(') {
		//Checks if the terminal is an opening parentheses before it continues to the expr inside, then the closing parantheses
		getNextLexeme();
		if (!expr()) return false;
		if (lexeme != ')') return false; // If there is no closing parentheses then it returns false
		getNextLexeme();
		return true;
	}
	return false;
}

bool term() {
	if (!factor()) return false;
	else if (lexeme == '+' || lexeme == '/') {
		getNextLexeme();
		if (!factor()) return false; // If there is an opererator the function makes sure the next lexeme after it is another term/factor
	}
	return true;
}

bool expr() {
	if (!term()) return false;
	else if (lexeme == '*' || lexeme == '-') {
		getNextLexeme();
		if (!term()) return false; // If there is an opererator the function makes sure the next lexeme after it is another term/factor
	}
	return true;
}


int main() {
	//Get input
	cout << "Enter a sentence(Enter to quit): ";
	getline(cin, input);

	while (input != "") {
		//While loop for multiple inputs
		num_lexemes = input.size();
		lexeme_index = -1;
		
		getNextLexeme();

		bool valid = expr() && lexeme == '\0'; //checks if the input is valid or not

		if (valid)
			cout << "'" << input << "' is a valid sentence" << endl;
		else
			cout << "'" << input << "' is not a valid sentence" << endl;

		cout << "Enter a sentence(Enter to quit): ";
		getline(cin, input);
	}
	return 0;
}