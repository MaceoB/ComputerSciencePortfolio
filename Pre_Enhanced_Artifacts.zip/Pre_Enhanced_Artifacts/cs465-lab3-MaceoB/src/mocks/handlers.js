import { http, HttpResponse } from 'msw'
import quizData from '../data/quiz.json'

let currentQuiz = {...quizData}
 

/*=================API ROUTES =====================*/
export const handlers = [
  http.get('/api/user', () => {
    return HttpResponse.json(currentQuiz)
  }),


  http.get('/api/topics', ({request}) => {
    const id = request.json();
    return HttpResponse.json(currentQuiz.topic[id])
  }),


  http.get('/', () => {
    return HttpResponse.text('<h1>Hello from MSW!</h1>')
  }),


  http.post("/api/user", async ({ request }) => {
    const newQuizData = await request.json(); // Read JSON body from the request

    // Example: merge or overwrite current quiz
    currentQuiz = { ...currentQuiz, ...newQuizData };

    // Respond with confirmation
    return HttpResponse.json({
      message: "Quiz data updated successfully!",
      updatedQuiz: currentQuiz,
    });
  }),

  http.post("/api/hello", async ({ request }) => {
    const {who, action} = await request.json();
    if(who === "qzicl" && action === "hello"){
      return HttpResponse.json({
      topics: currentQuiz.topic.map(t =>({
        title: t.title,
        id: t.topicID ?? null
      }))
    });
    }
  })
];
/*=================================================*/