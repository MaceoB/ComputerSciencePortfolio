import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

// Read quiz.json at runtime
const quizPath = path.join(__dirname, "src", "data", "quiz.json");
let currentQuiz = JSON.parse(fs.readFileSync(quizPath, "utf-8"));

// Middleware
app.use(express.json());

// Serve React static files
app.use(express.static(path.join(__dirname, "dist")));

/*=================API ROUTES =====================*/
app.get("/api/user", (req, res) => res.json(currentQuiz)); //responds with the current quiz data

app.get("/api/topics", (req, res) => {
  const id = req.query.id;
  if (id !== undefined && currentQuiz.topic[id]) {
    res.json(currentQuiz.topic[id]);
  } else {
    res.status(400).json({ error: "Invalid topic ID" });
  }
}); //responds with a list of topics

app.post("/api/user", (req, res) => {
  const newQuizData = req.body; //updates the new quiz using the old quiz as a request
  currentQuiz = { ...currentQuiz, ...newQuizData };
  res.json({ message: "Quiz updated", updatedQuiz: currentQuiz }); //Returns the new quiz data as a response
}); 

app.post("/api/hello", (req, res) => {
  const { who, action } = req.body; //takes in request from the user and the hello action
  if (who === "qzicl" && action === "hello") {
    res.json({
      topics: currentQuiz.topic.map((t, idx) => ({
        title: t.title,
        id: t.topicID ?? idx,
      })), //responds with a list of topics

    });
  } else {
    res.status(400).json({ error: "Invalid request" });
  }
});

/*=================================================*/


// Start server
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));