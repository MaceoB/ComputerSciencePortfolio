# Lab 3

This is the starter template for Lab3 CS465 Fall 2025.

This repository will be cloned into a new repo just for you! You can then clone that 
repository down to your development laptop and get started. I will also have access to your
repository for grading purposes.

As you work on the lab, you should regularly `git push` back to the classroom repository on GitHub.
When you are finished, be sure to add/commit/push !

Note: I will _only_ grade what's in the `main` branch of your personal repo created by GitHub
Classroom.

ccp
